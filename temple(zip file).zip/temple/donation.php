<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Temple Donation Form</title>
  <style>::after
   /*donation ...*/
   body {
   font-family: Arial, sans-serif;
   background-color: #f4f4f4;
   margin: 0;
   padding: 0;
   }
   .success-message {
    color: green;
    font-weight: bold;
  }

.success-message {
  color: green;
  font-weight: bold;
  font-size: 24px; /* Adjust the font size as needed */
}

.success-container img {
  width: 100px; /* Adjust the width of the image as needed */
  margin-bottom: 10px; /* Add some space between the image and message */
}
   
   .container {
   width: 50%;
   margin: 50px auto;
   background-color: #fff;
   padding: 20px;
   border-radius: 8px;
   box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
   }
   .don{
   background: url('tem.png') repeat-x;
     background-size: cover;
     animation: slideBg 30s linear infinite;
   
   }
   
   h2 {
   text-align: center;
   color: #333;
   }
   
   form {
   margin-top: 20px;
   }
   
   label {
   display: block;
   margin-bottom: 5px;
   color: #666;
   }
   
   input[type="text"],
   input[type="email"],
   input[type="number"],
   select {
   width: 100%;
   padding: 10px;
   margin-bottom: 15px;
   border: 1px solid #ccc;
   border-radius: 5px;
   box-sizing: border-box;
   }
   
   input[type="submit"] {
   background-color: #4caf50;
   color: #fff;
   border: none;
   padding: 15px 20px;
   cursor: pointer;
   border-radius: 5px;
   font-size: 16px;
   }
   
   input[type="submit"]:hover {
   background-color: #45a049;
   }
   </style>
</head>
<body class="don">
<div class="heading">
   <h3>your donation</h3>
   <p> <a href="home.php">home</a> / donation </p>
</div>
  <div class="container">
    <h2>Make a Donation</h2>
    <form  action="donation_connect.php" method="post">
      <label for="name">Your Name:</label>
      <input type="text" id="name" name="name" required>

      <label for="email">Email Address:</label>
      <input type="email" id="email" name="email" required>

      <label for="amount">Donation Amount (₹):</label>
      <input type="number" id="amount" name="amount" min="1" required>

      <label for="donation_type">Donation Type:</label>
      <select id="donation_type" name="donation_type" required>
        <option value="one_time">One-Time</option>
        <option value="recurring">Recurring</option>
      </select>

      <button type="submit">Submit</button>
    </form>
    <!-- End of the form -->

    
      
 
</body>
</html>