<?php
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $Name = $_POST['name'];
    $Email = $_POST['email'];
    $Mobile = $_POST['mobile'];
    $Date = $_POST['date'];
    $Time = $_POST['time'];
    
$con = new mysqli('localhost','root','','temple_db');
if ($con) {

   // echo "connection successful";
   $sql= " insert into darshana_bookings(name,email,mobile,date,time)values('$Name','$Email','$Mobile','$Date','$Time')";
   $result = mysqli_query($con,$sql);
   if($result) {
    echo "<div class='success-container'>
        <img src='pop.png' alt='Success Image'>
        <p class='success-message'>Darshana booking successfully done</p>
      </div>";

   }else {
    die(mysqli_error($con));

   }
} else{
    die(mysqli_error($con));
}
}