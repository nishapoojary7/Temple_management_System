<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Darshana Booking Form</title>
  <style>::after/* darshana*/
   body {
   font-family: Arial, sans-serif;
   background-color: #f4f4f4;
   margin: 0;
   padding: 0;
   }
  
   .success-container {
  display: flex;
  flex-direction: column;
  align-items: center; /* Center items horizontally */
  justify-content: center; /* Center items vertically */
  text-align: center; /* Center text horizontally */
}
.success-message {
    color: green;
    font-weight: bold;
  }

.success-message {
  color: green;
  font-weight: bold;
  font-size: 24px; /* Adjust the font size as needed */
}

.success-container img {
  width: 100px; /* Adjust the width of the image as needed */
  margin-bottom: 10px; /* Add some space between the image and message */
}

   .dar{
   background: url('amma.jpg') repeat-x;
     background-size: cover;
     animation: slideBg 30s linear infinite;
   
   }
   .container {
      width: 50%;
      margin: 50px auto;
      background-color: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      }
      
      h2 {
      text-align: center;
      color: #333;
      }
      
      form {
      margin-top: 20px;
      }
      
      label {
      display: block;
      margin-bottom: 5px;
      color: #666;
      }
      
      input[type="date"],
      select {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
      }
      
      input[type="submit"] {
      background-color: #4caf50;
      color: #fff;
      border: none;
      padding: 15px 20px;
      cursor: pointer;
      border-radius: 5px;
      font-size: 16px;
      width: 100%;
      }
      
      input[type="submit"]:hover {
      background-color: #45a049;
      }
      </style>
</head>
<body class="dar">
<div class="heading">
   <h3>your darshana</h3>
   <p> <a href="home.php">home</a> / darshana </p>
</div>
  <div class="container">
    <h2>Darshana Booking</h2>
    <form action=" darshana_connect.php" method="post">
    <div>
            <label>Name: </label>
            <Input type = "text" name = "name" placeholder = "Enter your name ">
        </div>
        <div>
            <label>Email: </label>
            <Input type = "email" name = "email" placeholder = "Enter your email ">
        </div>
        <div>
            <label>Mobile: </label>
            <Input type = "text" name = "mobile" placeholder = "Enter your mobile number ">
        </div>
        <div>
      <label for="date">Select Date:</label>
      <input type="date" id="date" name="date" required>

      <label for="time">Select Time Slot:</label>
      <select id="time" name="time" required>
        <option value="09:00">9:00 AM</option>
        <option value="10:00">10:00 AM</option>
        <option value="11:00">11:00 AM</option>
        <option value="12:00">12:00 PM</option>
        <option value="13:00">1:00 PM</option>
        <option value="14:00">2:00 PM</option>
        <option value="15:00">3:00 PM</option>
        <option value="16:00">4:00 PM</option>
        <option value="17:00">5:00 PM</option>
        <option value="18:00">6:00 PM</option>
        <option value="19:00">7:00 PM</option>
        <option value="20:00">8:00 PM</option>
      </select>

      <input type="submit" value="Book Darshana">
    </form>
  </div>

 
</body>
</html>
