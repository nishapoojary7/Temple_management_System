<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv = "X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>::after.container {
      width: 50%;
      margin: 50px auto;
      background-color: #fff;
      padding: 20px;
      display: flex;
    justify-content: center;
    align-items: center;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      }
      .success-message {
    color: green;
    font-weight: bold;
  }
  body {
   font-family: Arial, sans-serif;
   background-color: #f4f4f4;
   margin: 0;
   padding: 0;
   }
.success-message {
  color: green;
  font-weight: bold;
  font-size: 24px; /* Adjust the font size as needed */
}

.success-container img {
  width: 100px; /* Adjust the width of the image as needed */
  margin-bottom: 10px; /* Add some space between the image and message */
}
     
.don{
   background: url('tem.png') repeat-x;
     background-size: cover;
     animation: slideBg 30s linear infinite;
   
   }

.container {
      width: 50%;
      margin: 50px auto;
      background-color: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      }
      
      h2 {
      text-align: center;
      color: #333;
      }
      
      form {
      margin-top: 20px;
      }
      
      label {
      display: block;
      margin-bottom: 5px;
      color: #666;
      }
      
      input[type="date"],
      select {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
      }
      
      input[type="submit"] {
      background-color: #4caf50;
      color: #fff;
      border: none;
      padding: 20px 20px;
      cursor: pointer;
      border-radius: 5px;
      font-size: 16px;
      width: 100%;
      }
      
      input[type="submit"]:hover {
      background-color: #45a049;
      }
</style>
</head>
<body class="don">
<div class="heading">
   <h3>your Sevas</h3>
   <p> <a href="home.php">home</a> / sevas </p>
</div>
    
    <div class = "container">
    <form  action="connect.php" method="post">
        <h2>Seva</h2>
        <div>
            <label>Name: </label>
            <Input type = "text" name = "name" placeholder = "Enter your name ">
        </div>
        <div>
            <label>Email: </label>
            <Input type = "email" name = "email" placeholder = "Enter your email ">
        </div>
        
        <div>
            <label>Mobile: </label>
            <Input type = "text" name = "mobile" placeholder = "Enter your mobile number ">
        </div>
        <div>
            <label>Seva </label>
            <select name="seva_type" >
                <option> Kumkumarchane</option>
                <option>Rudrabisheka</option>
                <option>Karpoora Arathi</option>
                <option>Ashlesha pooja</option>
                <option>Ranga Poooja</option>
                <option>Ladoo Prasadam</option>
                </select>
        </div>
        <div>
            <label>Count</label>
            <select name="seva_count" >
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
                <option>6</option>
                </select>
        </div>
        <button type="submit">Submit</button>
    </form>
    <!-- End of the form -->
  </div>
</body>
</html>