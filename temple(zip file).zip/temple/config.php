<?php

$conn = mysqli_connect('localhost','root','','temple_db') or die('connection failed');

?>