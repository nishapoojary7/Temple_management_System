<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Services</title>

  <!-- font awesome cdn link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
       
<?php include 'header.php'; ?>

<div class="heading">
   <h3>your services</h3>
   <p> <a href="home.php">home</a> / Services </p>
</div>

<section class="content">
        <!-- Add icon library -->
<div class="card">
  <img src="sev.jpg"  style="width:50%">
 
  <p class="title">Sevas </p>
  <p>Kateel Durgaparamehwari</p>

  <p>
    <a href="sevas.php"><button>BOOK NOW</button></a>
  </p>
  
</div>
<div class="card2">
    <img src="img9.png"  style="width:50%">
   
    <p class="title">Donation </p>
    <p>Kateel Durgaparamehwari</p>
    <p>
      <a href="donation.php"><button>BOOK NOW</button></a>
  </p>

  </div>

  <div class="card3">
    <img src="img8.jpg"  style="width:50%">
   
    <p class="title">Darshana booking </p>
    <p>Kateel Durgaparamehwari</p>
    <p>
      <a href="darshana.php"><button>BOOK NOW</button></a>
  </p>
  </div>
</section>



















</body>
</html>