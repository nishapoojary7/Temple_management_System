<?php
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $Name = $_POST['name'];
    $Email = $_POST['email'];
    $Amount = $_POST['amount'];
    $Donation_type= $_POST['donation_type'];
    
    
$con = new mysqli('localhost','root','','temple_db');
if ($con) {

   // echo "connection successful";
   $sql= " insert into donation(name,email,amount,donation_type)values('$Name','$Email','$Amount','$Donation_type')";
   $result = mysqli_query($con,$sql);
   if($result) {
    echo "<div class='success-container'>
        <img src='pop.png' alt='Success Image'>
        <p class='success-message'>Donation  booking successfully done</p>
      </div>";

   }else {
    die(mysqli_error($con));

   }
} else{
    die(mysqli_error($con));
}
}