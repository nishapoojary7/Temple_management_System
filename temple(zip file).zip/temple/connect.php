<?php
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $Name = $_POST['name'];
    $Email = $_POST['email'];
    $Mobile = $_POST['mobile'];
    $Seva = $_POST['seva_type'];
    $Count = $_POST['seva_count'];
   
$con = new mysqli('localhost','root','','temple_db');
if ($con) {

   // echo "connection successful";
   $sql= " insert into seva_bookings(name,email,mobile,seva_type,seva_count)values('$Name','$Email','$Mobile','$Seva','$Count')";
   $result = mysqli_query($con,$sql);
   if($result) {
    echo "<div class='success-container'>
    <img src='pop.png' alt='Success Image'>
    <p class='success-message'>Seva booking successfully done</p>
  </div>";

   }else {
    die(mysqli_error($con));

   }
} else{
    die(mysqli_error($con));
}
}